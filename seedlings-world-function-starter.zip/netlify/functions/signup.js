const { createClient } = require("@supabase/supabase-js");
const { Resend } = require("resend");

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const resend = new Resend(process.env.RESEND_API_KEY);

function normalizeEmail(email) {
  return String(email || "").trim().toLowerCase();
}

exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const email = normalizeEmail(body.email);

    if (!email) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "Email required" }) };
    }

    const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!ok) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid email" }) };
    }

    const { data: existing } = await supabase
      .from("emails")
      .select("email")
      .eq("email", email)
      .maybeSingle();

    if (existing && existing.email) {
      return { statusCode: 200, headers, body: JSON.stringify({ status: "exists" }) };
    }

    const { error: insErr } = await supabase.from("emails").insert([{ email }]);

    if (insErr && String(insErr.message || "").toLowerCase().includes("duplicate")) {
      return { statusCode: 200, headers, body: JSON.stringify({ status: "exists" }) };
    }
    if (insErr) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: "Database insert failed" }) };
    }

    await resend.emails.send({
      from: "Seedlings <hello@seedlings.world>",
      to: email,
      subject: "Welcome to Seedlings.World 🌱",
      html: `
        <p><strong>Welcome to Seedlings.World, the next evolution of ownership.</strong></p>
        <p>
          You’re now part of a decentralized ecosystem where metallic art, NFC security,
          and dynamic NFTs merge into a living, breathing experience.
        </p>
        <p>
          Your Seedling will grow with every scan, every step,
          and every choice you make.
        </p>
      `,
    });

    return { statusCode: 200, headers, body: JSON.stringify({ status: "ok" }) };
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message || "Server error" }) };
  }
};
