# Seedlings.world — Signup Function

Deploy this folder via GitHub → Netlify (Import from Git).

Env vars needed:
- SUPABASE_URL
- SUPABASE_SERVICE_KEY
- RESEND_API_KEY
